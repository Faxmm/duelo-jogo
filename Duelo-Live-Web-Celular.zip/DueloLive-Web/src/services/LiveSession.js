import {TikTokLiveConnection,WebcastEvent,ControlEvent} from 'tiktok-live-connector';
import {normalizeChat,normalizeGift,normalizeLike,normalizeShare,normalizeUser} from '../lib/tiktokEventNormalizer.js';
import {GiftCounter} from '../lib/giftCounter.js';
import {randomUUID} from 'node:crypto';
export function safeError(error) {
  const message=String(error?.message||'').toLowerCase();
  if(/offline|not live|useroffline|room.*not found/.test(message))return 'O perfil ainda não está ao vivo. Nova tentativa em 30 s.';
  if(/429|rate.?limit|quota/.test(message))return 'Limite de consultas do conector. Nova tentativa em 30 s.';
  if(/403|401|sign|key|euler/.test(message))return 'TikTok ou serviço de assinatura recusou a conexão. Nova tentativa em 30 s.';
  return 'Não foi possível conectar. Verifique se a live está ativa. Nova tentativa em 30 s.';
}
export class LiveSession {
  constructor({onEvent,onStatus,onCatalog}) {Object.assign(this,{onEvent,onStatus,onCatalog});this.version=0;this.connection=null;this.timer=null;}
  async stop() {
    this.version++;clearTimeout(this.timer);this.timer=null;
    const old=this.connection;this.connection=null;
    if(old){old.removeAllListeners();old.on('error',()=>{});await old.disconnect().catch(()=>{});}
  }
  async start(username) {await this.stop();const version=this.version;await this.attempt(username,version);}
  retry(username,version) {
    if(version!==this.version)return;
    clearTimeout(this.timer);this.timer=setTimeout(()=>this.attempt(username,version),30000);
  }
  async attempt(username,version) {
    if(version!==this.version)return;
    this.onStatus({platform:'tiktok',status:'connecting',username,message:'Conectando ao TikTok…'});
    const connection=new TikTokLiveConnection(username,{processInitialData:false,enableExtendedGiftInfo:false,
      webClientOptions:{timeout:{request:12000}},wsClientOptions:{handshakeTimeout:12000}});
    this.connection=connection;const counter=new GiftCounter();
    const publish=(kind,payload)=>{if(this.connection===connection&&version===this.version)this.onEvent(username,kind,payload);};
    connection.on(WebcastEvent.CHAT,raw=>publish('chat',normalizeChat(raw)));
    connection.on(WebcastEvent.LIKE,raw=>publish('like',normalizeLike(raw)));
    connection.on(WebcastEvent.SHARE,raw=>publish('share',normalizeShare(raw)));
    connection.on(WebcastEvent.FOLLOW,raw=>publish('follow',{user:normalizeUser(raw),timestamp:Date.now()}));
    connection.on(WebcastEvent.GIFT,raw=>{const quantity=counter.count(raw);if(quantity)publish('gift',{...normalizeGift({...raw,repeatCount:quantity}),comboCount:Number(raw.repeatCount)||quantity,id:String(raw.common?.msgId||raw.msgId||randomUUID())+':'+String(raw.repeatCount||1)});});
    connection.on(ControlEvent.ERROR,()=>{});
    connection.on(ControlEvent.DISCONNECTED,()=>{
      if(this.connection!==connection||version!==this.version)return;
      this.onStatus({platform:'tiktok',status:'waiting',username,message:'Live desconectada. Tentando novamente em 30 s.'});this.retry(username,version);
    });
    try {
      const result=await connection.connect();
      if(version!==this.version||this.connection!==connection){await connection.disconnect().catch(()=>{});return;}
      this.onStatus({platform:'tiktok',status:'connected',username,message:'Conectado à sua live',roomId:result.roomId});
      // Gift metadata is optional: its endpoint failing must not abort the live connection.
      connection.fetchAvailableGifts().then(list=>{
        if(version===this.version)this.onCatalog(Array.isArray(list)?list:list?.gifts||[]);
      }).catch(()=>{});
    } catch(error) {
      if(version!==this.version)return;
      this.connection=null;connection.removeAllListeners();connection.on('error',()=>{});
      await connection.disconnect().catch(()=>{});
      this.onStatus({platform:'tiktok',status:'waiting',username,message:safeError(error)});this.retry(username,version);
    }
  }
}
