import express from 'express';
import {createServer} from 'node:http';
import {Server} from 'socket.io';
import WebSocket from 'ws';
import {dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {mkdirSync,readFileSync,writeFileSync,renameSync} from 'node:fs';
import {randomUUID} from 'node:crypto';
import {Urna} from './Urna.js';
import {LiveSession} from './services/LiveSession.js';
import {GiftCounter} from './lib/giftCounter.js';
import {normalizeGift} from './lib/tiktokEventNormalizer.js';
const project=dirname(dirname(fileURLToPath(import.meta.url))),port=Number(process.env.PORT||3005),data=process.env.URNA_DATA_DIR||join(process.env.APPDATA||project,'Urna-2026','game-data');mkdirSync(data,{recursive:true});
const sameOrigin=(q)=>{if(!q.headers.origin)return true;try{return new URL(q.headers.origin).host===q.headers.host;}catch{return false;}},app=express(),server=createServer(app),io=new Server(server,{maxHttpBufferSize:32768,allowRequest:(q,cb)=>cb(null,!!q.headers.host&&sameOrigin(q))}),game=new Urna();
const wsCounter=new GiftCounter();try{const c=JSON.parse(readFileSync(join(data,'ws-counter.json'),'utf8'));wsCounter.streaks=new Map(c.streaks);wsCounter.seen=new Map(c.seen);}catch{}
let settings={username:'',provider:'',reconnect:false,sound:true,volume:.35,music:true,musicVolume:.4,showGifts:true,wsUrl:'ws://127.0.0.1:21213/'},connection={status:'idle',message:'Pronto para abrir o jogo.'},auto=null,ws=null,retry=null,closing=false,saveError='';
try{game.restore(JSON.parse(readFileSync(join(data,'save.json'),'utf8')));}catch{}try{settings={...settings,...JSON.parse(readFileSync(join(data,'settings.json'),'utf8'))};}catch{}
try{settings.giftMapping=game.configureGifts(settings.giftMapping);}catch{settings.giftMapping=game.configureGifts();}
const state=()=>({...game.snapshot(),gifts:game.gifts.map(({key,name,side})=>({key,name,side})),sound:settings.sound,volume:settings.volume,music:settings.music,musicVolume:settings.musicVolume,showGifts:settings.showGifts,connection,saveError}),broadcast=()=>io.emit('urna:state',state());
function save(){try{for(const [name,value] of [['save.json',game.save()],['settings.json',settings],['ws-counter.json',{streaks:[...wsCounter.streaks],seen:[...wsCounter.seen]}]]){const f=join(data,name);writeFileSync(f+'.tmp',JSON.stringify(value));renameSync(f+'.tmp',f);}saveError='';return true;}catch(e){saveError=e.code==='ENOSPC'?'Sem espaço para salvar. Libere espaço no disco.':'Não foi possível salvar o placar. Verifique o disco.';return false;}}
function input(kind,payload,source){const r=game.input(kind,payload,source);if(r.accepted)save();broadcast();return r;}
const status=s=>{connection=s;broadcast();};
const live=new LiveSession({onStatus:status,onCatalog:list=>{for(const raw of list)game.registerGift(raw);},onEvent:(_u,kind,payload)=>{if(game.mode==='live'&&settings.provider==='tiktok')input(kind,payload,'tiktok');}});
function stopAuto(){clearInterval(auto);auto=null;}
async function disconnect(){stopAuto();clearTimeout(retry);retry=null;const old=ws;ws=null;old?.terminate();await live.stop();settings.reconnect=false;settings.provider='';}
function connectWS(url){const u=new URL(url);if(!['ws:','wss:'].includes(u.protocol)||!['127.0.0.1','localhost','[::1]'].includes(u.hostname)||u.username||u.password)throw Error('Use um WebSocket local (localhost).');
 const counter=wsCounter,client=new WebSocket(u,{maxPayload:32768,handshakeTimeout:5000});ws=client;status({status:'connecting',message:'Conectando ao WebSocket local…',transport:'websocket'});
 client.on('open',()=>{if(ws===client)status({status:'connected',message:'WebSocket conectado. Aguardando Rosa/Rosa Branca.',transport:'websocket'});});client.on('error',()=>{});
 client.on('message',bytes=>{if(ws!==client||game.mode!=='live')return;try{const b=JSON.parse(bytes.toString()),kind=b.event||b.type||b.kind;if(!['gift','tiktok_gift'].includes(kind))return;const raw=b.data||b.payload||b,n=counter.count(raw);if(n)input('gift',{...normalizeGift({...raw,repeatCount:n}),comboCount:Number(raw.repeatCount)||n,id:String(raw.msgId||raw.common?.msgId||raw.id||randomUUID())+':'+String(raw.repeatCount||1)},'websocket');}catch{}});
 client.on('close',()=>{if(ws!==client)return;ws=null;status({status:'waiting',message:'WebSocket desconectado. Tentando novamente em 5 s.',transport:'websocket'});retry=setTimeout(()=>{if(settings.provider==='websocket'&&settings.reconnect)connectWS(url);},5000);});
}
function simulate(b){if(game.mode!=='demo')throw Error('Testes só funcionam no modo TESTE.');const gift=game.gifts.find(g=>g.key===b.gift);if(!gift)throw Error('Escolha Rosa ou Rosa Branca.');const count=Number(b.quantity??1);if(!Number.isInteger(count)||count<1||count>1000)throw Error('Quantidade de 1 a 1000.');return input('gift',{id:randomUUID(),giftName:gift.name,repeatCount:count,user:{nickname:String(b.nickname||'Teste').slice(0,50)}},'demo');}
app.disable('x-powered-by');app.use((q,r,next)=>{if(!q.headers.host||!sameOrigin(q))return r.status(403).end();r.setHeader('Cache-Control','no-store');r.setHeader('X-Content-Type-Options','nosniff');next();});app.use(express.json({limit:'32kb'}));app.use('/api',(q,r,next)=>{if(q.method!=='GET'&&(q.headers['x-game-control']!=='1'||!sameOrigin(q)))return r.status(403).end();next();});
app.get('/api/health',(_q,r)=>r.json({app:'urna-2026',version:'1.2.1',pid:process.pid,projectDirectory:project}));app.get('/api/state',(_q,r)=>r.json(state()));app.get('/api/settings',(_q,r)=>r.json(settings));
app.post('/api/simulate',(q,r)=>{try{r.json({result:simulate(q.body),state:state()});}catch(e){r.status(400).json({error:e.message});}});
app.post('/api/control',async(q,r)=>{try{const b=q.body;
 if(b.action==='demo'){await disconnect();game.mode='demo';status({status:'idle',message:'TESTE — placar separado da LIVE.'});}
 else if(b.action==='socket'){await disconnect();game.mode='live';settings.provider='socket';settings.reconnect=true;status({status:'waiting',transport:'socket.io',message:'Socket.IO pronto em /socket.io. Envie urna:event.'});}
 else if(b.action==='websocket'){const url=String(b.url||settings.wsUrl);const u=new URL(url);if(!['ws:','wss:'].includes(u.protocol)||!['localhost','127.0.0.1','[::1]'].includes(u.hostname)||u.username||u.password)throw Error('WebSocket precisa ser local.');await disconnect();game.mode='live';settings.provider='websocket';settings.wsUrl=url;settings.reconnect=true;connectWS(url);}
 else if(b.action==='tiktok'){const username=String(b.username||'').trim().replace(/^@/,'').toLowerCase();if(!/^[a-z0-9._]{1,30}$/.test(username))throw Error('Informe seu perfil TikTok.');await disconnect();game.mode='live';settings.provider='tiktok';settings.username=username;settings.reconnect=true;live.start(username).catch(()=>{});}
 else if(b.action==='disconnect'){await disconnect();status({status:'idle',message:'Leitor desconectado.'});}
 else if(b.action==='pause')game.paused=!!b.paused;
 else if(b.action==='duration')game.configure(Number(b.seconds));
 else if(b.action==='final')game.close();
 else if(b.action==='reset-test'){stopAuto();game.resetTest();}
 else if(b.action==='gift-mapping'){if(!b.mapping||typeof b.mapping!=='object'||Array.isArray(b.mapping)||!b.mapping['white-rose']||!b.mapping.rose)throw Error('Configure as duas rosas.');settings.giftMapping=game.configureGifts(b.mapping);}
 else if(b.action==='gifts-visual')settings.showGifts=!!b.enabled;
 else if(b.action==='sound'){settings.sound=!!b.sound;settings.volume=Math.max(0,Math.min(1,Number(b.volume)||0));}
 else if(b.action==='music'){const v=Number(b.volume);if(!Number.isFinite(v)||v<0||v>1)throw Error('Volume da música de 0 a 1.');settings.music=!!b.enabled;settings.musicVolume=v;}
 else if(b.action==='auto'){if(game.mode!=='demo')throw Error('Use o modo TESTE.');stopAuto();let n=0;auto=setInterval(()=>simulate({gift:n++%3?'rose':'white-rose',quantity:1,nickname:['Ana','Pedro','Lia','Bruno'][n%4]}),1650);}
 else if(b.action==='stop-auto')stopAuto();else throw Error('Ação inválida.');save();broadcast();r.json(state());
 }catch(e){r.status(400).json({error:e.message});}});
app.get(['/','/overlay'],(_q,r)=>r.sendFile(join(project,'public/index.html')));app.get('/home',(_q,r)=>r.sendFile(join(project,'public/home.html')));app.get(['/control','/control.html','/control.js'],(_q,r)=>r.status(404).end());app.use(express.static(join(project,'public')));
io.on('connection',s=>{s.emit('urna:state',state());const accept=(b,ack)=>{const done=typeof ack==='function'?ack:()=>{};if(game.mode!=='live'||settings.provider!=='socket')return done({ok:false,error:'Ative Socket.IO no painel.'});if(!b||typeof b.id!=='string'||!b.id||b.id.length>120)return done({ok:false,error:'Envie um ID único.'});done(input(b.kind||'gift',{...b,user:{nickname:String(b.nickname||b.user?.nickname||'Visitante').slice(0,50)}},'socket'));};s.on('urna:event',accept);s.on('race:event',accept);});
let last=performance.now(),sent=0;const ticker=setInterval(()=>{const now=performance.now(),before=game.snapshot();game.tick(now-last);last=now;const after=game.snapshot();if(before.total!==after.total||before.phase!==after.phase)save();if(now-sent>40){broadcast();sent=now;}},16),saver=setInterval(save,2000);
async function shutdown(){if(closing)return;closing=true;clearInterval(ticker);clearInterval(saver);const provider=settings.provider,reconnect=settings.reconnect;await disconnect();settings.provider=provider;settings.reconnect=reconnect;save();io.close();server.close();process.exit(0);}
app.post('/api/shutdown',(_q,r)=>{r.once('finish',shutdown);r.json({ok:true});});process.on('SIGTERM',shutdown);process.on('SIGINT',shutdown);
server.listen(port,'0.0.0.0',()=>{console.log(`Urna 2026: http://127.0.0.1:${port}`);if(settings.reconnect){game.mode='live';if(settings.provider==='tiktok')live.start(settings.username).catch(()=>{});else if(settings.provider==='websocket')connectWS(settings.wsUrl);else if(settings.provider==='socket')status({status:'waiting',transport:'socket.io',message:'Socket.IO pronto. Aguardando presentes.'});}});
