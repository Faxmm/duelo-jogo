const key=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();
export const gifts=[{key:'white-rose',name:'Rosa Branca',side:'22',ids:[],aliases:['white rose','white roses','rosa branca','rosas brancas','whiterose']},{key:'rose',name:'Rosa',side:'13',ids:[5655],aliases:['rose','rosa','red rose','rosa vermelha']}];
export const ACTION_MS=1650, CONFIRM_MS=1120;
export const timings={first:350,second:720,confirm:CONFIRM_MS,total:ACTION_MS};
const fresh=()=>({round:1,votes:{13:0,22:0},wins:{13:0,22:0},queue:{13:[],22:[]},nextQueue:{13:[],22:[]},active:{13:null,22:null},handoff:{13:false,22:false},arrival:{13:null,22:null},feed:{13:null,22:null},remaining:300000,phase:'voting',reveal:0,winner:null,receipts:[]});
export class Urna {
 constructor(){this.mode='demo';this.paused=false;this.duration=300;this.clock=0;this.arenas={demo:fresh(),live:fresh()};this.configureGifts();}
 configureGifts(mapping={}){const next=gifts.map(g=>{const rule=mapping[g.key]||{},side=String(rule.side??g.side),id=Number(rule.id??0);if(!['13','22'].includes(side)||!Number.isSafeInteger(id)||id<0||id>2147483647)throw Error('Escolha um lado válido e um ID numérico para cada rosa.');return {...g,side,ids:id?[id]:[...g.ids],aliases:[...g.aliases],configuredId:id};});if(next[0].side===next[1].side)throw Error('Cada rosa precisa ficar em um lado diferente.');if(next[0].ids.some(id=>next[1].ids.includes(id)))throw Error('As duas rosas não podem usar o mesmo ID.');this.gifts=next;return Object.fromEntries(next.map(g=>[g.key,{side:g.side,id:g.configuredId}]));}
 registerGift(raw){const gift=this.gifts.find(g=>g.aliases.includes(key(raw.name)));const id=Number(raw.id);if(gift&&!gift.configuredId&&Number.isSafeInteger(id)&&id>0&&!this.gifts.some(g=>g.key!==gift.key&&g.ids.includes(id))&&!gift.ids.includes(id))gift.ids.push(id);}
 get arena(){return this.arenas[this.mode];}
 input(kind,payload={},source='socket'){
  if(kind!=='gift')return {ok:true,ignored:true,reason:'Somente Rosa e Rosa Branca pontuam.'};
  if((this.mode==='demo')!==(source==='demo'))return {ok:false,error:'Modo incompatível.'};
  const gift=this.gifts.find(g=>g.ids.includes(Number(payload.giftId)))||this.gifts.find(g=>g.aliases.includes(key(payload.giftName)));
  if(!gift)return {ok:true,ignored:true,reason:'Presente não habilitado.'};
  const count=Number(payload.repeatCount??1);if(!Number.isSafeInteger(count)||count<1||count>100000)return {ok:false,error:'Quantidade inválida.'};
  const a=this.arena,id=String(payload.id||'');if(!id||id.length>180)return {ok:false,error:'Evento sem ID válido.'};
  const receipt=source+':'+id;if(a.receipts.includes(receipt))return {ok:true,duplicate:true};
  if(!Number.isSafeInteger(a.votes[gift.side]+a.queue[gift.side].concat(a.nextQueue[gift.side]).reduce((n,x)=>n+x.count,0)+(a.active[gift.side]?.credited?0:a.active[gift.side]?.count||0)+count))return {ok:false,error:'Limite de pontos.'};
  a.receipts.push(receipt);if(a.receipts.length>20000)a.receipts.shift();
  const batch={id:receipt,side:gift.side,count,nickname:String(payload.user?.nickname||payload.nickname||'Visitante').slice(0,50),gift:gift.name};
  const displayCount=Number(payload.comboCount);a.arrival[gift.side]={...batch,displayCount:Number.isSafeInteger(displayCount)&&displayCount>=count&&displayCount<=100000?displayCount:count,at:this.clock};
  (a.phase==='voting'?a.queue:a.nextQueue)[gift.side].push(batch);this.startActions();return {ok:true,accepted:count,side:gift.side};
 }
 startActions(){const a=this.arena;if(this.paused||a.phase==='results')return;for(const side of ['22','13'])if(!a.active[side]&&a.queue[side].length){a.active[side]={...a.queue[side].shift(),started:this.clock,credited:false,fromConfirm:!!a.handoff[side]};a.handoff[side]=false;}}
 tick(ms){if(this.paused)return;ms=Math.max(0,Math.min(100,ms));this.clock+=ms;const a=this.arena;
  if(a.phase==='results'){a.reveal-=ms;if(a.reveal<=0){a.round=a.round>=99?1:a.round+1;a.votes={13:0,22:0};a.feed={13:null,22:null};a.winner=null;a.phase='voting';a.remaining=this.duration*1000;for(const s of ['13','22']){a.queue[s].push(...a.nextQueue[s]);a.nextQueue[s]=[];}this.startActions();}return;}
  this.startActions();if(a.phase==='voting'&&this.duration){a.remaining=Math.max(0,a.remaining-ms);if(!a.remaining)a.phase='draining';}
  for(const side of ['22','13']){const action=a.active[side];if(!action)continue;const age=this.clock-action.started;
   if(age>=CONFIRM_MS&&!action.credited){action.credited=true;a.votes[side]+=action.count;a.feed[side]={...action,at:this.clock};}
   if(age>=ACTION_MS){a.handoff[side]=a.queue[side].length>0;a.active[side]=null;}
  }
  this.startActions();if(a.phase==='draining'&&['13','22'].every(s=>!a.active[s]&&!a.queue[s].length))this.finish();
 }
 finish(){const a=this.arena;if(a.phase==='results')return;const winner=a.votes[13]===a.votes[22]?null:a.votes[13]>a.votes[22]?'13':'22';a.winner=winner;if(winner)a.wins[winner]++;a.phase='results';a.reveal=6000;}
 close(){if(this.arena.phase==='voting')this.arena.phase='draining';}
 configure(duration){if(!Number.isInteger(duration)||duration<0||duration>3600)throw Error('Duração de 0 a 3600 segundos.');this.duration=duration;if(this.arena.phase==='voting')this.arena.remaining=duration*1000;}
 resetTest(){this.arenas.demo=fresh();this.arenas.demo.remaining=this.duration*1000;}
 snapshot(){const a=this.arena,total=a.votes[13]+a.votes[22];return {version:1,timings,mode:this.mode,paused:this.paused,clock:this.clock,duration:this.duration,round:a.round,votes:a.votes,wins:a.wins,total,difference:Math.abs(a.votes[13]-a.votes[22]),leader:a.votes[13]===a.votes[22]?null:a.votes[13]>a.votes[22]?'13':'22',percent:{13:total?a.votes[13]/total*100:0,22:total?a.votes[22]/total*100:0},active:a.active,arrival:a.arrival,feed:a.feed,queued:{13:a.queue[13].reduce((n,x)=>n+x.count,0),22:a.queue[22].reduce((n,x)=>n+x.count,0)},remaining:a.remaining,phase:a.phase,winner:a.winner,reveal:a.reveal};}
 save(){return {version:1,mode:this.mode,paused:this.paused,duration:this.duration,clock:this.clock,arenas:this.arenas};}
 restore(data){if(data.version!==1)return;this.mode=data.mode==='live'?'live':'demo';this.paused=!!data.paused;this.duration=data.duration??300;this.clock=data.clock||0;for(const mode of ['demo','live'])if(data.arenas?.[mode])this.arenas[mode]={...fresh(),...data.arenas[mode]};}
}
