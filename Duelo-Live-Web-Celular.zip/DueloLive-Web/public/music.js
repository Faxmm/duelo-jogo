(()=>{
 const enabledByUrl=new URLSearchParams(location.search).get('sound')!=='0';
 const player=new Audio('/assets/urna-theme.mp3');player.loop=true;player.preload='auto';
 let enabled=false,starting=false,lastAttempt=-Infinity,blocked=false;
 const button=document.createElement('button');button.textContent='Ativar música';button.hidden=true;button.setAttribute('aria-label','Ativar a música de fundo');button.style.cssText='position:fixed;left:10px;bottom:10px;z-index:20;padding:10px 14px;border:1px solid #fff5;border-radius:10px;background:#172239;color:white;font:14px Arial;cursor:pointer';document.body.append(button);
 function play(){
  if(!enabled||blocked||!player.paused||starting||performance.now()-lastAttempt<1000)return;
  starting=true;lastAttempt=performance.now();
  player.play().then(()=>{blocked=false;button.hidden=true;}).catch(()=>{blocked=true;button.hidden=!enabled;}).finally(()=>starting=false);
 }
 function unlock(){if(player.error)player.load();blocked=false;lastAttempt=-Infinity;play();}
 button.onclick=unlock;document.addEventListener('pointerdown',unlock);document.addEventListener('keydown',unlock);
 player.addEventListener('playing',()=>{blocked=false;button.hidden=true;});
 player.addEventListener('error',()=>{button.textContent='Tentar música novamente';blocked=true;button.hidden=!enabled;});
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)unlock();});
 window.urnaMusic={sync(s){enabled=enabledByUrl&&s.music!==false;const v=Number(s.musicVolume??.4);player.volume=Number.isFinite(v)?Math.max(0,Math.min(1,v)):.4;button.hidden=!enabled||!blocked;if(enabled)play();else player.pause();},get element(){return player;},get status(){return{enabled,playing:!player.paused&&!player.ended,time:player.currentTime,volume:player.volume,ready:player.readyState,error:player.error?.code||null,blocked};}};
})();
