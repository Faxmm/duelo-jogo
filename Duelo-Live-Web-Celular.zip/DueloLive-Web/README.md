# Duelo Live — versão web

Esta é uma versão web do Duelo Live, com a tela de jogo e os recursos existentes no projeto. Ela precisa de um servidor Node.js para executar a lógica, guardar o placar e manter a conexão em tempo real; não basta abrir o `index.html` diretamente.

## Rodar localmente

1. Instale Node.js 20 ou mais recente.
2. No terminal, entre na pasta deste projeto.
3. Execute `npm install`.
4. Execute `npm start`.
5. Abra `http://localhost:3005` no navegador.

## Publicar na internet

Envie esta pasta para um serviço de hospedagem que aceite aplicações Node.js e WebSockets. Configure o comando de início como `npm start` e use a porta fornecida pela variável de ambiente `PORT`. Configure armazenamento persistente para a pasta `Urna-2026/game-data` (ou defina `URNA_DATA_DIR`). Use HTTPS na hospedagem. A conexão com TikTok e integrações locais de OBS/WebSocket podem precisar de ajustes específicos do ambiente de hospedagem; WebSockets locais do computador não ficam automaticamente acessíveis ao servidor remoto.


## Uso no celular
A interface foi ajustada para telas de celular e o jogo usa uma área vertical responsiva. Para usar no telefone, hospede este projeto em um servidor compatível com Node.js 20+ e WebSockets; depois abra o endereço HTTPS no navegador do celular. A página local `localhost` no computador não fica automaticamente acessível pela internet.

Comandos no servidor: `npm install` e `npm start`. Configure o serviço para usar a porta indicada pela variável `PORT`.
